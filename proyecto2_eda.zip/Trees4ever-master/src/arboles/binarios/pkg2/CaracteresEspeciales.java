import java.util.ArrayList;
import java.util.Arrays;

interface CaracteresEspeciales{

	ArrayList<Character> caracteres = new ArrayList<Character>(Arrays.asList('+','-', '*', '/'));
	
}